package com.pos.test.vendingmachine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendingmachineManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
